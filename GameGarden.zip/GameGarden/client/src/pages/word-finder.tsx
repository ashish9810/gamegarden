import WordFinderGame from "@/components/word-finder-game";

export default function WordFinder() {
  return <WordFinderGame initialLevel={1} />;
}
