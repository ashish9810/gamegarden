import NPATGame from "@/components/npat-game";

export default function NPAT() {
  return <NPATGame initialMode="single" />;
}
